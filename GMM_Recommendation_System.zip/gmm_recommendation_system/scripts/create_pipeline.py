"""
scripts/create_pipeline.py
==========================
Create or update the SageMaker Pipeline for GMM training.

Usage
-----
    python scripts/create_pipeline.py --upsert --start
    python scripts/create_pipeline.py --upsert --baseline-bic 450000
"""

import argparse
import json
import logging
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.utils import load_config, get_sagemaker_config

logger = logging.getLogger("create_pipeline")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s - %(message)s")

try:
    import boto3
    import sagemaker
    from sagemaker.inputs import TrainingInput
    from sagemaker.model import Model
    from sagemaker.model_metrics import MetricsSource, ModelMetrics
    from sagemaker.processing import ProcessingInput, ProcessingOutput
    from sagemaker.sklearn.estimator import SKLearn
    from sagemaker.sklearn.processing import SKLearnProcessor
    from sagemaker.workflow.condition_step import ConditionStep
    from sagemaker.workflow.conditions import ConditionLessThanOrEqualTo
    from sagemaker.workflow.functions import JsonGet
    from sagemaker.workflow.model_step import ModelStep
    from sagemaker.workflow.parameters import (
        ParameterFloat,
        ParameterInteger,
        ParameterString,
    )
    from sagemaker.workflow.pipeline import Pipeline
    from sagemaker.workflow.properties import PropertyFile
    from sagemaker.workflow.step_collections import RegisterModel
    from sagemaker.workflow.steps import CacheConfig, ProcessingStep, TrainingStep
    SM_AVAILABLE = True
except ImportError:
    SM_AVAILABLE = False


def create_pipeline(cfg: dict, baseline_bic: float = None) -> "Pipeline":
    if not SM_AVAILABLE:
        raise ImportError("Install sagemaker and boto3: pip install sagemaker boto3")

    sm_cfg    = get_sagemaker_config(cfg)
    role      = sm_cfg["role_arn"]
    bucket    = sm_cfg["bucket"]
    region    = sm_cfg["region"]
    prefix    = cfg["data"]["sagemaker"]["prefix"]
    sk_ver    = sm_cfg["sklearn_version"]
    p_name    = sm_cfg["pipeline_name"]
    pkg_group = sm_cfg["model_package_group"]
    inst_train = sm_cfg["instance_type_training"]
    inst_proc  = sm_cfg["instance_type_processing"]
    enable_cache = sm_cfg.get("enable_cache", True)
    bic_thresh   = baseline_bic or sm_cfg.get("baseline_bic", 1e9)

    sess         = sagemaker.Session(boto3.Session(region_name=region))
    cache_cfg    = CacheConfig(enable_caching=enable_cache, expire_after="30d")
    s3_base      = f"s3://{bucket}/{prefix}"

    # --- Pipeline Parameters ---
    p_products    = ParameterString("ProductsS3Uri", default_value=f"{s3_base}/data/products_raw.csv")
    p_users       = ParameterString("UsersS3Uri",    default_value=f"{s3_base}/data/users.csv")
    p_invoices    = ParameterString("InvoicesS3Uri", default_value=f"{s3_base}/data/invoices.csv")
    p_n_min       = ParameterInteger("NComponentsMin",  default_value=cfg["training"]["n_components_min"])
    p_n_max       = ParameterInteger("NComponentsMax",  default_value=cfg["training"]["n_components_max"])
    p_cov         = ParameterString("CovarianceTypes",  default_value=",".join(cfg["training"]["covariance_types"]))
    p_rand        = ParameterInteger("RandomState",     default_value=cfg["training"]["random_state"])
    p_bic         = ParameterFloat("BaselineBIC",       default_value=bic_thresh)
    p_pkg_group   = ParameterString("ModelPackageGroup", default_value=pkg_group)

    processor = SKLearnProcessor(
        framework_version=sk_ver,
        instance_type=inst_proc,
        instance_count=1,
        role=role,
        sagemaker_session=sess,
    )

    # === Step 1: Preprocessing ===
    step_preprocess = ProcessingStep(
        name="GMMPreprocessing",
        processor=processor,
        inputs=[
            ProcessingInput(source=p_products, destination="/opt/ml/processing/input/products"),
            ProcessingInput(source=p_users,    destination="/opt/ml/processing/input/users"),
            ProcessingInput(source=p_invoices, destination="/opt/ml/processing/input/invoices"),
        ],
        outputs=[
            ProcessingOutput(output_name="preprocessed", source="/opt/ml/processing/output",
                             destination=f"{s3_base}/preprocessed"),
        ],
        code="src/data/preprocessing.py",
        arguments=["--config", "config/config.yaml"],
        cache_config=cache_cfg,
    )

    # === Step 2: Training ===
    estimator = SKLearn(
        entry_point="src/models/training.py",
        framework_version=sk_ver,
        instance_type=inst_train,
        instance_count=1,
        role=role,
        sagemaker_session=sess,
        hyperparameters={
            "n-components-min":  p_n_min,
            "n-components-max":  p_n_max,
            "covariance-types":  p_cov,
            "random-state":      p_rand,
        },
        output_path=f"{s3_base}/model-artifacts",
    )

    step_train = TrainingStep(
        name="GMMTraining",
        estimator=estimator,
        inputs={
            "products": TrainingInput(
                s3_data=step_preprocess.properties.ProcessingOutputConfig.Outputs[
                    "preprocessed"
                ].S3Output.S3Uri,
                content_type="text/csv",
            )
        },
        cache_config=cache_cfg,
    )

    # === Step 3: Evaluation ===
    eval_report = PropertyFile(
        name="EvaluationReport",
        output_name="evaluation",
        path="evaluation.json",
    )

    step_eval = ProcessingStep(
        name="GMMEvaluation",
        processor=processor,
        inputs=[
            ProcessingInput(
                source=step_train.properties.ModelArtifacts.S3ModelArtifacts,
                destination="/opt/ml/processing/model",
            ),
        ],
        outputs=[
            ProcessingOutput(output_name="evaluation", source="/opt/ml/processing/output",
                             destination=f"{s3_base}/evaluation"),
        ],
        code="src/models/evaluation.py",
        property_files=[eval_report],
        cache_config=cache_cfg,
    )

    # === Step 4: Create Model ===
    model = Model(
        image_uri=estimator.training_image_uri(),
        model_data=step_train.properties.ModelArtifacts.S3ModelArtifacts,
        sagemaker_session=sess,
        role=role,
        entry_point="src/inference.py",
    )

    step_model = ModelStep(
        name="GMMCreateModel",
        step_args=model.create(instance_type=inst_train),
    )

    # === Step 5: Register Model ===
    metrics = ModelMetrics(
        model_statistics=MetricsSource(
            s3_uri=f"{s3_base}/evaluation/evaluation.json",
            content_type="application/json",
        )
    )

    step_register = RegisterModel(
        name="GMMRegisterModel",
        estimator=estimator,
        model_data=step_train.properties.ModelArtifacts.S3ModelArtifacts,
        content_types=["application/json", "text/csv"],
        response_types=["application/json", "text/csv"],
        inference_instances=[inst_train, "ml.m5.xlarge"],
        transform_instances=[inst_train],
        model_package_group_name=p_pkg_group,
        approval_status="PendingManualApproval",
        model_metrics=metrics,
    )

    # === Step 6: Conditional Gate ===
    new_bic = JsonGet(
        step_name=step_eval.name,
        property_file=eval_report,
        json_path="metrics.bic",
    )

    step_condition = ConditionStep(
        name="GMMBICCondition",
        conditions=[ConditionLessThanOrEqualTo(left=new_bic, right=p_bic)],
        if_steps=[step_model, step_register],
        else_steps=[],
    )

    pipeline = Pipeline(
        name=p_name,
        parameters=[p_products, p_users, p_invoices, p_n_min, p_n_max,
                    p_cov, p_rand, p_bic, p_pkg_group],
        steps=[step_preprocess, step_train, step_eval, step_condition],
        sagemaker_session=sess,
    )

    logger.info("Pipeline '%s' built with 4 top-level steps.", p_name)
    return pipeline


def upload_data_to_s3(cfg: dict, local_data_dir: str = "data/raw") -> None:
    """Upload local CSVs to the S3 location configured in config.yaml."""
    sm_cfg   = get_sagemaker_config(cfg)
    bucket   = sm_cfg["bucket"]
    prefix   = cfg["data"]["sagemaker"]["prefix"]
    region   = sm_cfg["region"]
    s3       = boto3.client("s3", region_name=region)

    files = ["products_raw.csv", "users.csv", "invoices.csv"]
    for fname in files:
        local = os.path.join(local_data_dir, fname)
        if os.path.exists(local):
            key = f"{prefix}/data/{fname}"
            s3.upload_file(local, bucket, key)
            logger.info("Uploaded %s → s3://%s/%s", fname, bucket, key)
        else:
            logger.warning("File not found (skipped): %s", local)


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--config",       default="config/config.yaml")
    p.add_argument("--upsert",       action="store_true", help="Create/update pipeline in SageMaker")
    p.add_argument("--start",        action="store_true", help="Start execution after upsert")
    p.add_argument("--upload-data",  action="store_true", help="Upload local CSVs to S3 first")
    p.add_argument("--baseline-bic", type=float, default=None)
    p.add_argument("--no-cache",     action="store_true")
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    cfg  = load_config(args.config)

    if args.no_cache:
        cfg["sagemaker"]["enable_cache"] = False

    if args.upload_data:
        upload_data_to_s3(cfg)

    pipeline = create_pipeline(cfg, baseline_bic=args.baseline_bic)

    if args.upsert:
        sm_cfg = get_sagemaker_config(cfg)
        pipeline.upsert(role_arn=sm_cfg["role_arn"])
        logger.info("Pipeline upserted: %s", sm_cfg["pipeline_name"])

    if args.start:
        exec_ = pipeline.start()
        logger.info("Execution started: %s", exec_.arn)
