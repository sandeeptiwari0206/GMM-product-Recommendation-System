# GMM Product Recommendation System
__version__ = "1.0.0"
